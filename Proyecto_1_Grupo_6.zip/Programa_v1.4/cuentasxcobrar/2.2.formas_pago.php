<?php
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}
?>

<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Formas de pago</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
 <style>
    .bg-aguamarina {
        background-color: #26bfba;
        color: black;
    }
    .border-aguamarina {
        border-color: #26bfba;
    }
</style>
</head>
  <body class="bg-light">

    <div class="container mt-5">
        <div class="text-left mb-5">
            <img src="logo.png" alt="Logo" class="rounded-circle shadow" style="width: 150px; height: 150px; object-fit: cover;">
            <h2 class="mt-4 fw-bold">REGISTRO DE PAGO</h2>
        </div>   
            
        <div class="card shadow mb-4">
            
            <div class="card-header bg-aguamarina">
                <h5 class="mb-0">DETALLE</h5>
            </div>
            <div class="card-body bg-aguamarina">
                <form>
                    <div class="row mb-3 justify-content-center gx-5">
                        <div class="col-md-6">
                            <label for="codigo" class="form-label"><strong>Código</strong></label>
                            <input type="text" class="form-control" id="codigo" placeholder="Ingrese el código de pago">
                        </div>
                        <div class="col-md-6">
                            <label for="Nombre" class="form-label"><strong>Nombre</strong></label>
                            <input type="text" class="form-control" id="Nombre" placeholder="Ingrese el nombre del cliente">
                        </div>
                    </div>
                    <div class="row mb-3 justify-content-center gx-5">
                        <div class="col-md-6">
                            <label for="formaPago" class="form-label"><strong>Forma de pago</strong></label>
                            <select class="form-select" aria-label="Default select example">
                            <option selected>Seleccionar</option>
                            <option value="1">Transferencia</option>
                            <option value="2">Efectivo</option>
                            <option value="3">Cheque</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="cedula" class="form-label"><strong>Cédula</strong></label>
                            <input type="text" class="form-control" id="cedula" placeholder="Ingrese la Cédula">
                        </div>
                    </div>

                    <div class="d-flex justify-content-center gap-2">
                        <button type="button" class="btn btn-primary" onclick="mostrarMensaje('insertar')">Guardar</button>
                        <button type="button" class="btn btn-danger" onclick="mostrarMensaje('eliminar')">Eliminar</button>
                        <button type="button" class="btn btn-secondary" onclick="mostrarMensaje('modificar')">Modificar</button>
                        <button type="button" class="btn btn-warning" onclick="mostrarMensaje('buscar')">Buscar</button>
                    </div>
                </form>
            </div>
        </div>

            <table class="table table-hover table-responsive mb-5 table-bordered text-center">
                <thead class="table-dark">
                        <tr>
                            <th>Código</th>
                            <th>Cliente</th>
                            <th>Cédula</th>
                            <th>Forma de pago</th>
                        </tr>
                </thead>
                    <tbody>
                        <tr>
                            <td>GS-567</td>
                            <td>John Duarte</td>
                            <td>0967585393</td>
                            <td>Transferencia</td>
                        </tr>
                        <tr>
                            <td>JK-237</td>
                            <td>Emily Fernández</td>
                            <td>1245938212</td>
                            <td>Efectivo</td>
                        </tr>
                        <tr>
                            <td>BJ-890</td>
                            <td>Bob Johnson</td>
                            <td>1679804234</td>
                            <td>Cheque</td>
                        </tr>
                    </tbody>
            </table>
    </div>    
    </div>
        <div class="modal fade" id="mensajeModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalLabel">Notificación del sistema</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center" id="textoMensajeModal">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
            </div>
        </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>        
    <script>
        function mostrarMensaje(accion) {
        let mensaje = "";
        if(accion === 'insertar') mensaje = 'Datos insertados correctamente';
        else if(accion === 'modificar') mensaje = 'Datos actualizados correctamente';
        else if(accion === 'eliminar') mensaje = 'Datos eliminados correctamente';
        else if(accion === 'buscar') mensaje = 'Búsqueda completada';

        document.getElementById('textoMensajeModal').innerHTML = "<strong>" + mensaje + "</strong>";
        var mensajeModal = new bootstrap.Modal(document.getElementById('mensajeModal'));
        mensajeModal.show();
        }
    </script>
</body>
</html>